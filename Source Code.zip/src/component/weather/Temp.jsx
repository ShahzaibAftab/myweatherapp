import React, { useEffect, useState } from 'react'
import Card from './Card'
const Temp = () => {
 const [searchValue, setSearchValue]=useState("lahore");
 const [tempInfo, SettempInfo]=useState({});
// async
 const getWeatherInfo = async()=>{
 try {
    let url='https://api.openweathermap.org/data/2.5/weather?q='+ searchValue + '&units=metric&appid=d5e8d5d06d7004a294c2d0f288d4c4ca';

    const res= await fetch(url);
    const data= await res.json();

    const {temp,humidity,pressure}=data.main;
    const {main: weathermood}=data.weather[0];
    const {name}=data;
    const {speed}=data.wind;
    const {country,sunset}=data.sys;

    const myNewWeatherInfo={
        temp,humidity,pressure,weathermood,name,speed,country,sunset
    };
    SettempInfo(myNewWeatherInfo);
    //console.log(temp);
    // console.log(data);
} catch (error) {
    console.log(error);
 }
 }

 useEffect(()=>{
    getWeatherInfo();
 },[]);
  return (
    <section className='mainContainer'>
        <div className='inputField'>
            <input className='dataField' placeholder='Search..' value={searchValue} onChange={(e)=>{setSearchValue(e.target.value)}}/>
            <button className='Button' onClick={getWeatherInfo}>Search</button>
        </div>
          <Card tempInfo={tempInfo}/>
        </section>
  )
}

export default Temp