import React,{useEffect, useState} from 'react'
import {TbSunset2} from 'react-icons/tb'
import {MdOutlineAir} from 'react-icons/md'
import {FaRegClock} from 'react-icons/fa'
import {BsCloudHazeFill} from 'react-icons/bs'
import {WiDaySunnyOvercast} from 'react-icons/wi'
import {RiHazeLine} from 'react-icons/ri'
import {WiHumidity} from 'react-icons/wi'
import {WiDaySunny} from 'react-icons/wi'
import {WiCloudy} from 'react-icons/wi'
import './Card.css'
const Card = ({tempInfo}) => {
const [weatherState,setweatherState]=useState("");
    const{
        temp,
        humidity,
        pressure,
        weathermood,
        name,
        speed,
        country,
        sunset
    }=tempInfo;
    useEffect(()=>{
        if(weathermood)
        {
            switch(weathermood)
            {
                case "Cloud":setweatherState(<WiCloudy className='icon'/>); break;
                case "Clear":setweatherState(<WiDaySunny className='icon'/>); break;
                case "Haze":setweatherState(<RiHazeLine className='icon'/>); break;
                case "Sunny":setweatherState(<WiDaySunnyOvercast className='icon'/>); break;
            }
        }
        
     },[weathermood]);
    // seconds to time conversion
    let sec=sunset;
    let date=new Date(sec*1000);
    // let timeStr=  date.getHours() + date.getMinutes();
  return (
    <section className='mainContainer'>
        <div className='body'>
            <div className='upperSection'>
                {weatherState}
                {console.log(weatherState)}
                {/* <TiWeatherPartlySunny className='icon'/> */}
               <div className='flexAlign'>
                <h6>Weather Web Application</h6>
                <span>Search in your your City</span>
                </div>
                
                </div>
            <div className='midSection'>
                <div className='midLeft'>
                    <h6 className='tempDeg'> {temp}° </h6>
                    <div className='weather'>
                        <h6>{weathermood}</h6>
                        <span>{name}, {country}</span>
                        </div>
                    </div>
                <div className='midRight'>
                    <FaRegClock className='icon'/>
                 <h6> {new Date().toLocaleString()} </h6></div>
            </div>
            <div className='lowerSection'>
                <div className='lowerOne'>
                    <TbSunset2 className='icon'/>
                    <h6>{date.getHours()% 12}:{date.getMinutes()} <span><br/>Sunset</span></h6>
                  </div>
                <div className='lowerTwo'>
                    <WiHumidity className='icon'/>
                    <h6>{humidity} <span><br/>Humidity</span></h6>
                </div>
                <div className='lowerThree'>
                    <BsCloudHazeFill className='icon'/>
                    <h6>{pressure} <span><br/>Pressure</span></h6>
                </div>
                <div className='lowerFour'>
                    <MdOutlineAir className='icon'/>
                    <h6>{speed}<span><br/>Speed</span></h6>
                </div>
            </div>
        </div>
    </section>
  )
}

export default Card