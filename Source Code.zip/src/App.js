import Temp from "./component/weather/Temp";
import "./App.css";

function App() {
  return (
    <>
      <Temp />
    </>
  );
}

export default App;
